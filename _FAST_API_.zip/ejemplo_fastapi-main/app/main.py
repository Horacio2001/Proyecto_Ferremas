from fastapi import FastAPI 
from app.routers import clientes
from app.routers import productos
from app.routers import marcas
from app.routers import inventarios
from app.routers import empleados
from app.routers import pagos
from app.routers import pedidos



app = FastAPI(
    title="API de FERREMAS",
    version="1.0.0",
    description="API gestion de datos FERREMAS - FastAPI + Oracle"
)

#Traeremos lo de las rutas(routers):
app.include_router(clientes.router)
app.include_router(productos.router)
app.include_router(marcas.router)
app.include_router(inventarios.router)
app.include_router(empleados.router)
app.include_router(pagos.router)
app.include_router(pedidos.router)

@app.get("/")
async def root():
    return {"PARA VER LOS DATOS IR A ": "/DOCS/"}