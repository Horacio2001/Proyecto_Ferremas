import oracledb 

oracledb.init_oracle_client(lib_dir=r"C:\oraclexe\instantclient-basic-windows.x64-23.8.0.25.04\instantclient_23_8")

def get_conexion():
    conexion = oracledb.connect(
        user="Ferremas",
        password="Ferremas",
        dsn="localhost:1521/xe"
    )
    return conexion
