from fastapi import APIRouter, HTTPException
from app.database import get_conexion
from typing import Optional
from fastapi import HTTPException

#vamos a crear la variable para las rutas:
router = APIRouter(
    prefix="/pedidos",
    tags=["Pedidos"]
)

#endpoints: GET, GET, POST, PUT, DELETE, PATCH ------------------------------------
@router.get("/pedidos/")
def obtener_pedidos():
    try:
        cone = get_conexion()
        cursor = cone.cursor()

        cursor.execute("""
            SELECT 
                p.id_pedido,
                
                -- Cliente
                c.nombre AS cliente_nombre,
                c.apellido AS cliente_apellido,
                
                -- Estado del pedido
                ep.desc_estado,
                
                -- Pago
                pag.fecha_pago,
                tp.tipo_pago,
                
                -- Empleado
                e.nombre AS empleado_nombre,
                e.apellido AS empleado_apellido

            FROM pedido p
            JOIN cliente c ON p.cliente_id_cliente = c.id_cliente
            JOIN estado_pedido ep ON p.estado_pedido_id_estado = ep.id_estado
            JOIN pago pag ON p.pago_id_pago = pag.id_pago
            JOIN tipo_pago tp ON pag.tipo_pago_id_tipopago = tp.id_tipopago
            JOIN empleado e ON p.empleado_id_empleado = e.id_empleado
        """)

        pedidos = []
        for row in cursor:
            (
                id_pedido,
                cliente_nombre, cliente_apellido,
                desc_estado,
                fecha_pago, tipo_pago,
                empleado_nombre, empleado_apellido
            ) = row

            pedidos.append({
                "id_pedido": id_pedido,
                "cliente": f"{cliente_nombre} {cliente_apellido}",
                "estado": desc_estado,
                "pago": {
                    "fecha_pago": fecha_pago.strftime('%Y-%m-%d'),
                    "tipo_pago": tipo_pago
                },
                "empleado": f"{empleado_nombre} {empleado_apellido}"
            })

        cursor.close()
        cone.close()
        return pedidos

    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
    
#METOODO AGREGAR PEDIDO 
@router.post("/pedido/")
def crear_pedido(pedido_data: dict):
    try:
        cone = get_conexion()
        cursor = cone.cursor()

        # 1. Insertar en PAGO
        cursor.execute("""
            INSERT INTO pago (id_pago, fecha_pago, tipo_pago_id_tipopago)
            VALUES (id_pago_seq.nextval, SYSDATE, :tipo_pago_id)
            RETURNING id_pago INTO :id_pago
        """, {
            "tipo_pago_id": pedido_data["tipo_pago_id"],
            "id_pago": cursor.var(int)
        })
        id_pago = cursor.getimplicitresults()[0][0]

        # 2. Insertar en PEDIDO
        cursor.execute("""
            INSERT INTO pedido (id_pedido, cliente_id_cliente, estado_pedido_id_estado, pago_id_pago, empleado_id_empleado)
            VALUES (id_pedido_seq.nextval, :cliente_id, :estado_id, :pago_id, :empleado_id)
            RETURNING id_pedido INTO :id_pedido
        """, {
            "cliente_id": pedido_data["cliente_id"],
            "estado_id": pedido_data["estado_id"],
            "pago_id": id_pago,
            "empleado_id": pedido_data["empleado_id"],
            "id_pedido": cursor.var(int)
        })
        id_pedido = cursor.getimplicitresults()[0][0]

        # 3. Insertar en DETALLE_PEDIDO
        for detalle in pedido_data["detalles"]:
            cursor.execute("""
                INSERT INTO detalle_pedido (id_detalle, cantidad, precio_unidad, producto_id_producto, pedido_id_pedido)
                VALUES (id_detalle_pedido_seq.nextval, :cantidad, :precio_unidad, :producto_id, :pedido_id)
            """, {
                "cantidad": detalle["cantidad"],
                "precio_unidad": detalle["precio_unidad"],
                "producto_id": detalle["producto_id"],
                "pedido_id": id_pedido
            })

        cone.commit()
        cursor.close()
        cone.close()

        return {"mensaje": "Pedido registrado con éxito", "id_pedido": id_pedido}

    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))