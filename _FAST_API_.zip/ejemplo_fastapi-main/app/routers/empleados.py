from fastapi import APIRouter, HTTPException
from app.database import get_conexion

#vamos a crear la variable para las rutas:
router = APIRouter(
    prefix="/empleado",
    tags=["Empleado"]
)

#endpoints: GET, GET, POST, PUT, DELETE, PATCH
@router.get("/")
def obtener_empleados():
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("""
            SELECT e.id_empleado,
                   e.usuario,
                   e.contrasena,
                   e.rut,
                   e.nombre,
                   e.apellido,
                   s.nombre AS sucursal,
                   r.nombre_rol AS rol
            FROM empleado e
            JOIN sucursal s ON e.sucursal_id_sucursal = s.id_sucursal
            JOIN rol r ON e.rol_id_rol = r.id_rol
        """)
        empleados = []
        for id_empleado, usuario, contrasena, rut, nombre, apellido, sucursal, rol in cursor:
            empleados.append({
                "id_empleado": id_empleado,
                "usuario": usuario,
                "contrasena": contrasena,
                "rut": rut,
                "nombre": nombre,
                "apellido": apellido,
                "sucursal": sucursal,
                "rol": rol
            })
        cursor.close()
        cone.close()
        return empleados
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))

@router.post("/login")
def login_empleado(usuario: str, contrasena: str):
    try:
        conn = get_conexion()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT e.id_empleado, e.nombre, r.nombre_rol
            FROM empleado e
            JOIN rol r ON e.rol_id_rol = r.id_rol
            WHERE e.usuario = :usuario AND e.contrasena = :contrasena
        """, {"usuario": usuario, "contrasena": contrasena})
        row = cursor.fetchone()
        cursor.close()
        conn.close()

        if row:
            return {
                "id_empleado": row[0],
                "nombre": row[1],
                "rol": row[2],  # Nombre del rol desde la tabla rol
                "mensaje": "Login exitoso"
            }
        else:
            raise HTTPException(status_code=401, detail="Usuario o contraseña incorrectos")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@router.delete("/{rut_eliminar}")
def eliminar_empleado(rut_eliminar: str):
    """
    Elimina un empleado por su RUT
    
    Parámetros:
        rut_eliminar (str): RUT del empleado a eliminar (formato: '12345678-9')
    
    Retorna:
        dict: Mensaje de éxito o error
    """
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        
        # Eliminar empleado por RUT
        cursor.execute("DELETE FROM empleado WHERE rut = :rut", {"rut": rut_eliminar})
        
        # Verificar si se eliminó algún registro
        if cursor.rowcount == 0:
            cursor.close()
            cone.close()
            raise HTTPException(
                status_code=404, 
                detail=f"No se encontró empleado con RUT {rut_eliminar}"
            )
        
        cone.commit()
        cursor.close()
        cone.close()
        
        return {"mensaje": f"Empleado con RUT {rut_eliminar} eliminado con éxito"}
        
    except HTTPException:
        raise  # Re-lanzamos las excepciones HTTP que ya hemos manejado
    except Exception as ex:
        if 'cone' in locals():
            cone.rollback()
        raise HTTPException(
            status_code=500, 
            detail=f"Error al eliminar empleado: {str(ex)}"
        )
    finally:
        if 'cone' in locals() and cone:
            if 'cursor' in locals() and cursor:
                cursor.close()
            cone.close()

@router.post("/empleado/cambiar-contrasena")
def cambiar_contrasena_empleado(usuario: str, nueva_contrasena: str):
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        
        # Validar nueva contraseña (ejemplo básico)
        if len(nueva_contrasena) < 8:
            raise HTTPException(status_code=400, detail="La contraseña debe tener al menos 8 caracteres")
            
        # Actualizar en base de datos
        cursor.execute(
            "UPDATE empleado SET contrasena = :contrasena, cambio_contrasena = 0 WHERE usuario = :usuario",
            {"contrasena": hashlib.sha256(nueva_contrasena.encode()).hexdigest(), "usuario": usuario}
        )
        
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
            
        cone.commit()
        return {"mensaje": "Contraseña actualizada correctamente"}
        
    except Exception as ex:
        cone.rollback()
        raise HTTPException(status_code=500, detail=str(ex))
    finally:
        if 'cone' in locals():
            cone.close()