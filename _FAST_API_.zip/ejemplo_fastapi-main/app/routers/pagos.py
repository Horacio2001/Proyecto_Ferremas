from fastapi import APIRouter, HTTPException
from app.database import get_conexion
from typing import Optional
from fastapi import HTTPException

#vamos a crear la variable para las rutas:
router = APIRouter(
    prefix="/pagos",
    tags=["Pagos"]
)

#endpoints: GET, GET, POST, PUT, DELETE, PATCH ------------------------------------

@router.get("/pagos/")
def obtener_pagos():
    try:
        conexion = get_conexion()
        cursor = conexion.cursor()
        cursor.execute("""
            SELECT 
                p.id_pago,
                p.fecha_pago,
                t.tipo_pago
            FROM pago p
            JOIN tipo_pago t ON p.tipo_pago_id_tipopago = t.id_tipopago
        """)
        pagos = []
        for id_pago, fecha_pago, tipo_pago in cursor:
            pagos.append({
                "id_pago": id_pago,
                "fecha_pago": fecha_pago,
                "tipo_pago": tipo_pago  # aquí devuelve el nombre
            })
        cursor.close()
        conexion.close()
        return pagos
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


#METODO INGRESAR PAGO
@router.post("/pagos/")
def agregar_pago(tipo_pago_id_tipopago: int):
    try:
        conexion = get_conexion()
        cursor = conexion.cursor()
        cursor.execute("""
            INSERT INTO pago (id_pago, fecha_pago, tipo_pago_id_tipopago)
            VALUES (id_pago_seq.nextval, SYSDATE, :tipo_pago_id_tipopago)
        """, {
            "tipo_pago_id_tipopago": tipo_pago_id_tipopago
        })
        conexion.commit()
        cursor.close()
        conexion.close()
        return {"mensaje": "Pago agregado con éxito"}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))