from fastapi import APIRouter, HTTPException
from app.database import get_conexion
from typing import Optional
from fastapi import HTTPException

#vamos a crear la variable para las rutas:
router = APIRouter(
    prefix="/inventario",
    tags=["Inventario"]
)

#endpoints: GET, GET, POST, PUT, DELETE, PATCH ------------------------------------
@router.get("/inventarios")
def obtener_inventarios():
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("""
            SELECT i.id_inventario,
                   i.stock,
                   p.nombre AS nombre_producto
            FROM inventario i
            JOIN producto p ON i.producto_id_producto = p.id_producto
        """)
        inventarios = []
        for id_inventario, stock, nombre_producto in cursor:
            inventarios.append({
                "id_inventario": id_inventario,
                "stock": stock,
                "nombre_producto": nombre_producto
            })
        cursor.close()
        cone.close()
        return inventarios
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
    
#METODO AGREGAR INVENTARIO 
@router.post("/inventario")
def agregar_inventario(stock: int, producto_id_producto: int, sucursal_id_sucursal: int):
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("""
            INSERT INTO inventario (id_inventario, stock, producto_id_producto, sucursal_id_sucursal)
            VALUES (id_inventario_seq.nextval, :stock, :producto_id_producto, :sucursal_id_sucursal)
        """, {
            "stock": stock,
            "producto_id_producto": producto_id_producto,
            "sucursal_id_sucursal": sucursal_id_sucursal
        })
        cone.commit()
        cursor.close()
        cone.close()
        return {"mensaje": "Inventario agregado con éxito"}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
    

#METODO ACTUALIZAR STOCK INVENTARIO 
@router.patch("/inventario/{id_inventario}")
def actualizar_stock_inventario(id_inventario: int, stock: int):
    try:
        cone = get_conexion()
        cursor = cone.cursor()

        cursor.execute("""
            UPDATE inventario
            SET stock = :stock
            WHERE id_inventario = :id_inventario
        """, {"stock": stock, "id_inventario": id_inventario})

        if cursor.rowcount == 0:
            cursor.close()
            cone.close()
            raise HTTPException(status_code=404, detail="Inventario no encontrado")

        cone.commit()
        cursor.close()
        cone.close()

        return {"mensaje": "Stock actualizado con éxito"}

    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
    
    
#METODO ELIMINAR INVENTARIO 
@router.delete("/inventario/{id_inventario}")
def eliminar_inventario(id_inventario: int):
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("DELETE FROM inventario WHERE id_inventario = :id", {"id": id_inventario})

        if cursor.rowcount == 0:
            cursor.close()
            cone.close()
            raise HTTPException(status_code=404, detail="Inventario no encontrado")

        cone.commit()
        cursor.close()
        cone.close()
        return {"mensaje": "Inventario eliminado con éxito"}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))