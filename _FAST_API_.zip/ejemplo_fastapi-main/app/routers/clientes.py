from fastapi import APIRouter, HTTPException
from app.database import get_conexion

#vamos a crear la variable para las rutas:
router = APIRouter(
    prefix="/cliente",
    tags=["Cliente"]
)

#endpoints: GET, GET, POST, PUT, DELETE, PATCH

#METODO TODOS LOS CLIENTES --------------------------------------------------
@router.get("/")
def obtener_usuarios():
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("""
            SELECT c.id_cliente, c.usuario, c.rut, c.correo, c.direccion,
                   c.nombre, c.apellido, r.nombre_rol AS rol
            FROM cliente c
            JOIN rol r ON c.id_rol = r.id_rol
        """)
        usuarios = []
        for id_cliente, usuario, rut, correo, direccion, nombre, apellido, rol in cursor:
            usuarios.append({
                "id_cliente": id_cliente,
                "usuario": usuario,
                "rut": rut,
                "correo": correo,
                "direccion": direccion,
                "nombre": nombre,
                "apellido": apellido,
                "rol": rol
            })
        cursor.close()
        cone.close()
        return usuarios
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
    

#METODO BUSCAR CLIENTE POR RUT -----------------------------------------
@router.get("/{rut_buscar}") 
def obtener_usuario(rut_buscar: int):
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("SELECT nombre, apellido, correo FROM cliente WHERE rut = :rut"
                       ,{"rut": rut_buscar})
        usuario = cursor.fetchone()
        cursor.close()
        cone.close()
        if not usuario:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
        return {
            "rut": rut_buscar,
            "nombre": usuario[0],
            "apellido": usuario[1],
            "email": usuario[2]
        }
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))

@router.post("/")
def agregar_usuario(
    usuario: str,
    contrasena: str,
    rut: int,
    nombre: str,
    apellido: str,
    email: str,
    telefono: int,
    direccion: str
):
    try:
        cone = get_conexion()
        cursor = cone.cursor()

        # Insertar y devolver el ID usando RETURNING INTO
        id_cliente_var = cursor.var(int)

        cursor.execute("""
            INSERT INTO cliente (
                id_cliente, usuario, contrasena, rut, nombre, apellido, correo, telefono, direccion
            ) VALUES (
                id_cliente_seq.nextval, :usuario, :contrasena, :rut, :nombre, :apellido, :email, :telefono, :direccion
            ) RETURNING id_cliente INTO :id_cliente
        """, {
            "usuario": usuario,
            "contrasena": contrasena,
            "rut": rut,
            "nombre": nombre,
            "apellido": apellido,
            "email": email,
            "telefono": telefono,
            "direccion": direccion,
            "id_cliente": id_cliente_var
        })

        cone.commit()
        id_cliente = id_cliente_var.getvalue()
        cursor.close()
        cone.close()

        return {
            "mensaje": "Cliente agregado con éxito",
            "id_cliente": id_cliente
        }

    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
    

#METODO ACTUALIZAR INFORMACION CLIENTE
@router.put("/{rut_actualizar}")
def actualizar_usuario(rut_actualizar:int, nombre:str, apellido:str, email:str):
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("""
                UPDATE cliente
                SET nombre = :nombre, apellido = :apellido, email = :email
                WHERE rut = :rut
        """, {"nombre":nombre, "apellido":apellido, "email":email, "rut":rut_actualizar})
        if cursor.rowcount==0:
            cursor.close()
            cone.close()
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
        cone.commit()
        cursor.close()
        cone.close()
        return {"mensaje": "Usuario actualizado con éxito"}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


#METODO ELIMINAR CLIENTE
@router.delete("/{rut_eliminar}")
def eliminar_usuario(rut_eliminar: int):
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("DELETE FROM cliente WHERE rut = :rut"
                       ,{"rut": rut_eliminar})
        if cursor.rowcount==0:
            cursor.close()
            cone.close()
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
        cone.commit()
        cursor.close()
        cone.close()
        return {"mensaje": "Usuario eliminado con éxito"}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))

#ACTUALIZAR INFORMACION DE CLIENTE DE FORMA OPCIONAL POR DATO INSERTADO
from typing import Optional
@router.patch("/{rut_actualizar}")
def actualizar_parcial(rut_actualizar:int, nombre:Optional[str]=None, apellido:Optional[str]=None, email:Optional[str]=None):
    try:
        if not nombre and not email and not apellido:
            raise HTTPException(status_code=400, detail="Debe enviar al menos 1 dato")
        cone = get_conexion()
        cursor = cone.cursor()

        campos = []
        valores = {"rut": rut_actualizar}
        if nombre:
            campos.append("nombre = :nombre")
            valores["nombre"] = nombre
        if apellido:
            campos.append("apellido = :apellido")
            valores["apellido"] = apellido
        if email:
            campos.append("email = :email")
            valores["email"] = email

        cursor.execute(f"UPDATE cliente SET {', '.join(campos)} WHERE rut = :rut"
                       ,valores)
        if cursor.rowcount==0:
            cursor.close()
            cone.close()
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
        cone.commit()
        cursor.close()
        cone.close()        
        return {"mensaje": "Usuario actualizado con éxito"}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))

@router.post("/login")
def login_cliente(usuario: str, contrasena: str):
    try:
        conn = get_conexion()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id_cliente, usuario, nombre, apellido FROM cliente
            WHERE usuario = :usuario AND contrasena = :contrasena
        """, {"usuario": usuario, "contrasena": contrasena})
        row = cursor.fetchone()
        cursor.close()
        conn.close()

        if row:
            return {
                "id_cliente": row[0],
                "usuario": row[1],
                "nombre": row[2],
                "apellido": row[3],
                "rol": "cliente",               # <-- agregado
                "mensaje": "Login exitoso"
            }
        else:
            raise HTTPException(status_code=401, detail="Usuario o contraseña incorrectos")

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))