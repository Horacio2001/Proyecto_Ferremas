from fastapi import APIRouter, HTTPException
from app.database import get_conexion
from typing import Optional
from fastapi import HTTPException

#vamos a crear la variable para las rutas:
router = APIRouter(
    prefix="/marca",
    tags=["Marca"]
)
@router.get("/marcas")
def obtener_marcas():
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("""
            SELECT id_marca, nombre
            FROM marca
        """)
        marcas = []
        for id_marca, nombre in cursor:
            marcas.append({
                "id_marca": id_marca,
                "nombre": nombre
            })
        cursor.close()
        cone.close()
        return marcas
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))

#MNETODO AGREGAR MARCA --------------------------------------
@router.post("/marcas")
def agregar_marca(nombre: str):
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("""
            INSERT INTO marca (id_marca, nombre)
            VALUES (id_marca_seq.nextval, :nombre)
        """, {
            "nombre": nombre
        })
        cone.commit()
        cursor.close()
        cone.close()
        return {"mensaje": "Marca agregada con éxito"}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
    

#METODO ACTUALIZAR MARCA ------------------------------------------------------------------------------------
@router.patch("/marcas/{id_marca}")
def actualizar_marca_parcial(id_marca: int, nombre: Optional[str] = None):
    try:
        if nombre is None:
            raise HTTPException(status_code=400, detail="Debe enviar el nombre para actualizar")

        cone = get_conexion()
        cursor = cone.cursor()

        cursor.execute("""
            UPDATE marca
            SET nombre = :nombre
            WHERE id_marca = :id_marca
        """, {"nombre": nombre, "id_marca": id_marca})

        if cursor.rowcount == 0:
            cursor.close()
            cone.close()
            raise HTTPException(status_code=404, detail="Marca no encontrada")

        cone.commit()
        cursor.close()
        cone.close()

        return {"mensaje": "Marca actualizada con éxito"}

    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
    
#METODO ELIMINAR MARCA -----------------------------------
@router.delete("/marcas/{id_marca}")
def eliminar_marca(id_marca: int):
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("DELETE FROM marca WHERE id_marca = :id", {"id": id_marca})

        if cursor.rowcount == 0:
            cursor.close()
            cone.close()
            raise HTTPException(status_code=404, detail="Marca no encontrada")

        cone.commit()
        cursor.close()
        cone.close()
        return {"mensaje": "Marca eliminada con éxito"}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
