from fastapi import APIRouter, HTTPException
from app.database import get_conexion
from typing import Optional
from fastapi import HTTPException

#vamos a crear la variable para las rutas:
router = APIRouter(
    prefix="/producto",
    tags=["Producto"]
)

#endpoints: GET, GET, POST, PUT, DELETE, PATCH ------------------------------------
@router.get("/")
def obtener_productos():
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("""
            SELECT p.id_producto,
                   p.nombre,
                   p.descripcion,
                   p.precio,
                   m.nombre AS marca
            FROM producto p
            JOIN marca m ON p.marca_id_marca = m.id_marca
        """)
        productos = []
        for id_producto, nombre, descripcion, precio, marca in cursor:
            productos.append({
                "id_producto": id_producto,
                "nombre": nombre,
                "descripcion": descripcion,
                "precio": precio,
                "marca": marca
            })
        cursor.close()
        cone.close()
        return productos
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


#MNETODO AGREGAR PRODUCTO --------------------------------------
@router.post("/")
def agregar_producto(nombre: str, descripcion: str, precio: int, marca_id_marca: int):
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("""
            INSERT INTO producto (id_producto, nombre, descripcion, precio, marca_id_marca)
            VALUES (id_producto_seq.nextval, :nombre, :descripcion, :precio, :marca_id_marca)
        """, {
            "nombre": nombre,
            "descripcion": descripcion,
            "precio": precio,
            "marca_id_marca": marca_id_marca
        })
        cone.commit()
        cursor.close()
        cone.close()
        return {"mensaje": "Producto agregado con éxito"}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))

#METODO ACTUALIZAR INFORMACION PRODUCTO ---------------------------------------------
@router.patch("/{id_producto}")
def actualizar_producto_parcial(
    id_producto: int,
    nombre: Optional[str] = None,
    descripcion: Optional[str] = None,
    precio: Optional[float] = None,
    marca_id_marca: Optional[int] = None
):
    try:
        if not any([nombre, descripcion, precio, marca_id_marca]):
            raise HTTPException(status_code=400, detail="Debe enviar al menos un dato para actualizar")

        cone = get_conexion()
        cursor = cone.cursor()

        campos = []
        valores = {"id_producto": id_producto}

        if nombre is not None:
            campos.append("nombre = :nombre")
            valores["nombre"] = nombre

        if descripcion is not None:
            campos.append("descripcion = :descripcion")
            valores["descripcion"] = descripcion

        if precio is not None:
            campos.append("precio = :precio")
            valores["precio"] = precio

        if marca_id_marca is not None:
            campos.append("marca_id_marca = :marca_id_marca")
            valores["marca_id_marca"] = marca_id_marca

        sql = f"UPDATE producto SET {', '.join(campos)} WHERE id_producto = :id_producto"
        cursor.execute(sql, valores)

        if cursor.rowcount == 0:
            cursor.close()
            cone.close()
            raise HTTPException(status_code=404, detail="Producto no encontrado")

        cone.commit()
        cursor.close()
        cone.close()

        return {"mensaje": "Producto actualizado con éxito"}

    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))


#METODO ELIMINAR PRODUCTO -----------------------------------
@router.delete("/{id_producto}")
def eliminar_producto(id_producto: int):
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("DELETE FROM producto WHERE id_producto = :id", {"id": id_producto})

        if cursor.rowcount == 0:
            cursor.close()
            cone.close()
            raise HTTPException(status_code=404, detail="Producto no encontrado")

        cone.commit()
        cursor.close()
        cone.close()
        return {"mensaje": "Producto eliminado con éxito"}
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
    




#OBTENER PRODUCTO CON INVENTARIO
@router.get("/productos-con-stock")
def obtener_productos_con_stock():
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("""
            SELECT p.id_producto, p.nombre, p.descripcion, p.precio, m.nombre AS marca, i.stock
            FROM producto p
            JOIN inventario i ON p.id_producto = i.producto_id_producto
            JOIN marca m ON p.marca_id_marca = m.id_marca
        """)
        productos = []
        for id_producto, nombre, descripcion, precio, marca, stock in cursor:
            productos.append({
                "id_producto": id_producto,
                "nombre": nombre,
                "descripcion": descripcion,
                "precio": precio,
                "marca": marca,
                "stock": stock
            })
        cursor.close()
        cone.close()
        return productos
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
    
@router.get("/producto/{id_producto}")
def obtener_producto_por_id(id_producto: int):
    try:
        cone = get_conexion()
        cursor = cone.cursor()
        cursor.execute("""
            SELECT p.id_producto, p.nombre, p.descripcion, p.precio, m.nombre AS marca
            FROM producto p
            JOIN marca m ON p.marca_id_marca = m.id_marca
            WHERE p.id_producto = :id
        """, {"id": id_producto})
        row = cursor.fetchone()

        if not row:
            raise HTTPException(status_code=404, detail="Producto no encontrado")

        producto = {
            "id_producto": row[0],
            "nombre": row[1],
            "descripcion": row[2],
            "precio": row[3],
            "marca": row[4]
        }

        # Puedes agregar stock si quieres también aquí
        cursor.execute("""
            SELECT stock FROM inventario WHERE producto_id_producto = :id
        """, {"id": id_producto})
        stock_row = cursor.fetchone()
        producto["stock"] = stock_row[0] if stock_row else 0

        cursor.close()
        cone.close()
        return producto

    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
