DROP TABLE cliente CASCADE CONSTRAINTS;

DROP TABLE comuna CASCADE CONSTRAINTS;

DROP TABLE detalle_pedido CASCADE CONSTRAINTS;

DROP TABLE empleado CASCADE CONSTRAINTS;

DROP TABLE estado_pedido CASCADE CONSTRAINTS;

DROP TABLE inventario CASCADE CONSTRAINTS;

DROP TABLE marca CASCADE CONSTRAINTS;

DROP TABLE pago CASCADE CONSTRAINTS;

DROP TABLE pedido CASCADE CONSTRAINTS;

DROP TABLE producto CASCADE CONSTRAINTS;

DROP TABLE region CaASCADE CONSTRAINTS;

DROP TABLE rol CASCADE CONSTRAINTS;

DROP TABLE sucursal CASCADE CONSTRAINTS;

DROP TABLE tipo_pago CASCADE CONSTRAINTS;

CREATE TABLE cliente (
    id_cliente       INTEGER NOT NULL,
    usuario          VARCHAR (20) NOT NULL,
    contrasena       VARCHAR (20) NOT NULL,
    rut              INTEGER NOT NULL,
    nombre           VARCHAR2(50) NOT NULL,
    apellido         VARCHAR2(50) NOT NULL,
    correo           VARCHAR2(100) NOT NULL,
    telefono         INTEGER NOT NULL,
    direccion        VARCHAR2(100) NOT NULL
);

ALTER TABLE cliente ADD CONSTRAINT cliente_pk PRIMARY KEY ( id_cliente );
ALTER TABLE cliente ADD id_rol INTEGER;

CREATE TABLE comuna (
    id_comuna          INTEGER NOT NULL,
    nombre_comuna      VARCHAR2(50) NOT NULL,
    region_region_id   NUMBER NOT NULL
);

ALTER TABLE comuna ADD CONSTRAINT comuna_pk PRIMARY KEY ( id_comuna );

CREATE TABLE detalle_pedido (
    id_detalle             INTEGER NOT NULL,
    cantidad               INTEGER NOT NULL,
    precio_unidad          INTEGER NOT NULL,
    producto_id_producto   INTEGER NOT NULL,
    pedido_id_pedido       INTEGER NOT NULL
);

ALTER TABLE detalle_pedido ADD CONSTRAINT detalle_pedido_pk PRIMARY KEY ( id_detalle );

CREATE TABLE empleado (
    id_empleado            INTEGER NOT NULL,
    usuario                VARCHAR (20) NOT NULL,
    contrasena             VARCHAR (20) NOT NULL,
    nombre                 VARCHAR2(100) NOT NULL,
    apellido               VARCHAR2(100) NOT NULL,
    rut                    VARCHAR2(10) NOT NULL,
    sucursal_id_sucursal   INTEGER NOT NULL,
    rol_id_rol             INTEGER NOT NULL
);

ALTER TABLE empleado ADD CONSTRAINT empleado_pk PRIMARY KEY ( id_empleado );

CREATE TABLE estado_pedido (
    id_estado     INTEGER NOT NULL,
    desc_estado   VARCHAR2(20) NOT NULL
);

ALTER TABLE estado_pedido ADD CONSTRAINT estado_pedido_pk PRIMARY KEY ( id_estado );

CREATE TABLE inventario (
    id_inventario          INTEGER NOT NULL,
    stock                  INTEGER NOT NULL,
    producto_id_producto   INTEGER NOT NULL,
    sucursal_id_sucursal   INTEGER NOT NULL
);

ALTER TABLE inventario ADD CONSTRAINT inventario_pk PRIMARY KEY ( id_inventario );

CREATE TABLE marca (
    id_marca   INTEGER NOT NULL,
    nombre     VARCHAR2(60) NOT NULL
);

ALTER TABLE marca ADD CONSTRAINT marca_pk PRIMARY KEY ( id_marca );

CREATE TABLE pago (
    id_pago                 INTEGER NOT NULL,
    fecha_pago              DATE NOT NULL,
    tipo_pago_id_tipopago   INTEGER NOT NULL
);

ALTER TABLE pago ADD CONSTRAINT pago_pk PRIMARY KEY ( id_pago );

CREATE TABLE pedido (
    id_pedido                 INTEGER NOT NULL,
    cliente_id_cliente        INTEGER NOT NULL,
    estado_pedido_id_estado   INTEGER NOT NULL,
    pago_id_pago              INTEGER NOT NULL,
    empleado_id_empleado      INTEGER NOT NULL
);

ALTER TABLE pedido ADD CONSTRAINT pedido_pk PRIMARY KEY ( id_pedido );

CREATE TABLE producto (
    id_producto      INTEGER NOT NULL,
    nombre           VARCHAR2(50) NOT NULL,
    descripcion      VARCHAR2(200) NOT NULL,
    precio           INTEGER NOT NULL,
    marca_id_marca   INTEGER NOT NULL
);

ALTER TABLE producto ADD CONSTRAINT producto_pk PRIMARY KEY ( id_producto );

CREATE TABLE region (
    id_region       INTEGER NOT NULL,
    nombre_region   VARCHAR2(50) NOT NULL,
    region_id       NUMBER NOT NULL
);

ALTER TABLE region ADD CONSTRAINT region_pk PRIMARY KEY ( region_id );

CREATE TABLE rol (
    id_rol       INTEGER NOT NULL,
    nombre_rol   VARCHAR2(50) NOT NULL
);

ALTER TABLE rol ADD CONSTRAINT rol_pk PRIMARY KEY ( id_rol );

CREATE TABLE sucursal (
    id_sucursal        INTEGER NOT NULL,
    nombre             VARCHAR2(50) NOT NULL,
    direccion          VARCHAR2(100) NOT NULL,
    comuna_id_comuna   INTEGER NOT NULL
);

ALTER TABLE sucursal ADD CONSTRAINT sucursal_pk PRIMARY KEY ( id_sucursal );

CREATE TABLE tipo_pago (
    id_tipopago   INTEGER NOT NULL,
    tipo_pago     VARCHAR2(100) NOT NULL
);

ALTER TABLE tipo_pago ADD CONSTRAINT tipo_pago_pk PRIMARY KEY ( id_tipopago );

/

ALTER TABLE cliente
ADD CONSTRAINT fk_cliente_rol
FOREIGN KEY (id_rol)
REFERENCES rol(id_rol);

ALTER TABLE comuna
    ADD CONSTRAINT comuna_region_fk FOREIGN KEY ( region_region_id )
        REFERENCES region ( region_id );

ALTER TABLE detalle_pedido
    ADD CONSTRAINT detalle_pedido_pedido_fk FOREIGN KEY ( pedido_id_pedido )
        REFERENCES pedido ( id_pedido );

ALTER TABLE detalle_pedido
    ADD CONSTRAINT detalle_pedido_producto_fk FOREIGN KEY ( producto_id_producto )
        REFERENCES producto ( id_producto );

ALTER TABLE empleado
    ADD CONSTRAINT empleado_rol_fk FOREIGN KEY ( rol_id_rol )
        REFERENCES rol ( id_rol );

ALTER TABLE empleado
    ADD CONSTRAINT empleado_sucursal_fk FOREIGN KEY ( sucursal_id_sucursal )
        REFERENCES sucursal ( id_sucursal );

ALTER TABLE inventario
    ADD CONSTRAINT inventario_producto_fk FOREIGN KEY ( producto_id_producto )
        REFERENCES producto ( id_producto );

ALTER TABLE inventario
    ADD CONSTRAINT inventario_sucursal_fk FOREIGN KEY ( sucursal_id_sucursal )
        REFERENCES sucursal ( id_sucursal );

            
ALTER TABLE pago
    ADD CONSTRAINT pago_tipo_pago_fk FOREIGN KEY ( tipo_pago_id_tipopago )
        REFERENCES tipo_pago ( id_tipopago );

ALTER TABLE pedido
    ADD CONSTRAINT pedido_cliente_fk FOREIGN KEY ( cliente_id_cliente )
        REFERENCES cliente ( id_cliente );

ALTER TABLE pedido
    ADD CONSTRAINT pedido_empleado_fk FOREIGN KEY ( empleado_id_empleado )
        REFERENCES empleado ( id_empleado );

ALTER TABLE pedido
    ADD CONSTRAINT pedido_estado_pedido_fk FOREIGN KEY ( estado_pedido_id_estado )
        REFERENCES estado_pedido ( id_estado );

ALTER TABLE pedido
    ADD CONSTRAINT pedido_pago_fk FOREIGN KEY ( pago_id_pago )
        REFERENCES pago ( id_pago );

ALTER TABLE producto
    ADD CONSTRAINT producto_marca_fk FOREIGN KEY ( marca_id_marca )
        REFERENCES marca ( id_marca );

ALTER TABLE sucursal
    ADD CONSTRAINT sucursal_comuna_fk FOREIGN KEY ( comuna_id_comuna )
        REFERENCES comuna ( id_comuna );
        
CREATE OR REPLACE TRIGGER region_region_id_trg BEFORE
    INSERT ON region
    FOR EACH ROW
    WHEN ( new.region_id IS NULL )
BEGIN
    :new.region_id := region_region_id_seq.nextval;
END;

/
CREATE SEQUENCE region_region_id_seq START WITH 1 NOCACHE ORDER;
CREATE SEQUENCE id_cliente_seq start with 1;
CREATE SEQUENCE id_marca_seq START WITH 1;
CREATE SEQUENCE id_producto_seq START WITH 1;
CREATE SEQUENCE id_inventario_seq START WITH 1;
CREATE SEQUENCE id_empleado_seq START WITH 1;
CREATE SEQUENCE id_pedido_seq START WITH 1;
CREATE SEQUENCE id_pago_seq START WITH 1;



/
    insert into REGION values(1,'Santiago',1);
    insert into REGION values(2,'Valparaiso',2);
/
    insert into COMUNA values(1,'Puente Alto',1);
    insert into COMUNA values(2, 'La Florida',1);
    insert into COMUNA values(3, 'Macul',1);
/
    insert into SUCURSAL values(1, 'Ferremas Puente', 'Av. concha y toro 981', 1);
/
    insert into MARCA values(id_marca_seq.nextval,'DEWALT');
/
    insert into PRODUCTO values(id_producto_seq.nextval, 'Taladro','Inal?mbrico Prcutor',185000,1);
/ 
    insert into INVENTARIO values(id_inventario_seq.nextval, 40, 1,1);
    insert into INVENTARIO values(id_inventario_seq.nextval, 60, 3,1);
/
    insert into CLIENTE values(id_cliente_seq.nextval,'Ema','hola123',20745324,'Emmanuel','Lobos','emalob@duocuc.cl',82823456,'Av Matta 765',4);
/
    insert into ROL values(1,'contador');
    insert into ROL values(2,'bodeguero');
    insert into ROL values(3,'vendedor'); 
    insert into ROL values(4,'cliente'); 
    insert into ROL values(5,'admin'); 
/
    insert into EMPLEADO values(id_empleado_seq.nextval,'gabriel','hola123', 'Gabriel','Navarro',20888999, 1, 1);
    insert into EMPLEADO values(id_empleado_seq.nextval,'benjamin','hola123', 'Benjamin','Gonzalez',20222333, 1, 2);
    insert into EMPLEADO values(id_empleado_seq.nextval,'juliano','hola123', 'Julianno','Troncoso',21000222, 1, 3);
    insert into EMPLEADO values(id_empleado_seq.nextval,'admin1','admin123', 'Admin','Mayor',12384593, 1, 5);
/
    insert into TIPO_PAGO values(1,'Tarjeta');
    insert into TIPO_PAGO values(2,'Transferencia');
/
    insert into PAGO values(id_pago_seq.nextval,sysdate, 1);
/
    insert into ESTADO_PEDIDO values(1,'PENDIENTE');
    insert into ESTADO_PEDIDO values(2,'APROBADO');
    insert into ESTADO_PEDIDO values(3,'RECHAZADO');
/
    insert into PEDIDO values(id_pedido_seq.nextval,1,1,1,1);
/
    
COMMIT;
/






